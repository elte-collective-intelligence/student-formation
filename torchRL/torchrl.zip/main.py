import hydra
from omegaconf import DictConfig, OmegaConf
import torch
import time
from tensordict.nn import TensorDictSequential
from torchrl.collectors import SyncDataCollector
from torchrl.data.replay_buffers import ReplayBuffer
from torchrl.data.replay_buffers.storages import LazyTensorStorage
from torchrl.objectives import ClipPPOLoss
from torchrl.objectives.value import GAE
from torch.utils.tensorboard import SummaryWriter
import tqdm

# Imports assuming main.py is in the root, and src is a package in the root
from src.envs.env import FormationEnv
from src.agents.ppo_agent import create_ppo_actor_critic
from src.rollout.evaluator import evaluate_policy

@hydra.main(version_base=None, config_path="./configs", config_name="experiment/default_exp") # <--- CHANGE HERE
def main(cfg: DictConfig) -> None:
    print(OmegaConf.to_yaml(cfg))
    
    device = torch.device(cfg.base.device)  # <--- CHANGE HERE: cfg.base.device
    torch.manual_seed(cfg.base.seed)        # <--- CHANGE HERE: cfg.base.seed
    if device == torch.device("cuda"):
        torch.cuda.manual_seed_all(cfg.base.seed) # <--- CHANGE HERE: cfg.base.seed

    # Environment
    proof_env = FormationEnv(cfg=cfg, device=device)
    create_env_fn = lambda: FormationEnv(cfg=cfg, device=device)

    # Agent (Policy and Value Function)
    actor_network, value_network = create_ppo_actor_critic(cfg, proof_env)
    actor_network = actor_network.to(device)
    value_network = value_network.to(device)

    # Data Collector
    collector = SyncDataCollector(
        create_env_fn=create_env_fn,
        policy=actor_network,
        frames_per_batch=cfg.algo.frames_per_batch,
        total_frames=cfg.algo.total_frames,
        device=device,
    )

    # Replay Buffer
    replay_buffer = ReplayBuffer(
        storage=LazyTensorStorage(max_size=cfg.algo.frames_per_batch),
        batch_size=None, 
    )

    # Loss Module
    loss_module = ClipPPOLoss(
        actor=actor_network,
        critic=value_network,
        clip_epsilon=cfg.algo.clip_epsilon,
        entropy_coef=cfg.algo.entropy_coef,
        value_loss_coef=cfg.algo.value_loss_coef,
    )
    loss_module = loss_module.to(device)

    # Advantage Module (GAE)
    adv_module = GAE(
        gamma=cfg.algo.gamma,
        lmbda=cfg.algo.gae_lambda,
        value_network=value_network,
        average_gae=True
    )
    adv_module = adv_module.to(device)

    # Optimizer
    optimizer = torch.optim.Adam(
        loss_module.parameters(),
        lr=cfg.algo.lr
    )

    # Logging
    # Ensure the log_dir path is relative to where main.py is run or use absolute paths
    # If main.py is in root, "logs/..." is fine.
    log_dir_path = f"logs/{cfg.base.project_name}/{time.strftime('%Y%m%d-%H%M%S')}"
    print(f"Tensorboard logs will be saved to: {log_dir_path}")
    writer = SummaryWriter(log_dir=log_dir_path)


    # Training Loop
    pbar = tqdm.tqdm(total=cfg.algo.total_frames)
    collected_frames = 0

    for i, data_batch in enumerate(collector):
        current_frames = data_batch.numel()
        pbar.update(current_frames)
        collected_frames += current_frames
        
        data_batch = data_batch.to(device)
        batch_for_loss = data_batch.reshape(-1)

        with torch.no_grad():
            adv_module(batch_for_loss)

        replay_buffer.extend(batch_for_loss)

        for _ in range(cfg.algo.ppo_epochs):
            for sample in replay_buffer:
                loss_td = loss_module(sample)
                
                actor_loss = loss_td["loss_actor"]
                critic_loss = loss_td["loss_critic"]
                entropy_loss = loss_td["loss_entropy"]
                total_loss = actor_loss + critic_loss + entropy_loss

                optimizer.zero_grad()
                total_loss.backward()
                optimizer.step()

        if i % cfg.log_interval == 0:
            writer.add_scalar("Loss/Actor", actor_loss.item(), collected_frames)
            writer.add_scalar("Loss/Critic", critic_loss.item(), collected_frames)
            writer.add_scalar("Loss/Entropy", entropy_loss.item(), collected_frames)
            writer.add_scalar("Loss/Total", total_loss.item(), collected_frames)
            
            mean_batch_reward = data_batch["reward"].sum(dim=1).mean().item()
            writer.add_scalar("Reward/MeanBatchReward", mean_batch_reward, collected_frames)
            
            print(f"Iter {i}: Frames {collected_frames}, Mean Batch Reward: {mean_batch_reward:.2f}, Total Loss: {total_loss.item():.2f}")

        if collected_frames >= cfg.algo.total_frames:
            break
            
    pbar.close()
    collector.shutdown()
    writer.close()
    proof_env.close()
    print("Training finished.")

    # torch.save(actor_network.state_dict(), "actor_model.pt")
    # torch.save(value_network.state_dict(), "value_model.pt")

if __name__ == "__main__":
    main()