import torch
from tensordict import TensorDict, TensorDictBase
from tensordict.nn import TensorDictSequential
from torchrl.envs import EnvBase
from torchrl.data import UnboundedContinuousTensorSpec, CompositeSpec, BoundedTensorSpec, DiscreteTensorSpec
import math

class FormationEnv(EnvBase):
    metadata = {
        "render_modes": ["human", "rgb_array"], # Add if you implement rendering
        "render_fps": 30,
    }
    batch_locked = False # Important for MARL using shared policies typically

    def __init__(self, cfg, device="cpu"):
        super().__init__(device=device)
        self.num_agents = cfg.env.num_agents
        self.arena_size = cfg.env.arena_size
        self.max_steps = cfg.env.max_steps
        self.target_radius = cfg.env.target_radius
        self.current_step = 0

        # Define action and observation specs
        # Actions: 2D continuous movement (dx, dy) for each agent
        # Observations:
        #   - agent's own position (2D)
        #   - vector to its target position (2D)
        #   - (Optional for critic) all agent positions, all target positions
        self._make_specs()

        # For CTDE: specify which observation keys are for the actor
        self.actor_obs_keys = cfg.env.obs_keys # ["observation_self", "observation_target_vector"]
        # Critic could potentially use more, e.g., "observation_all_positions" if added

    def _make_specs(self) -> None:
        self.observation_spec = CompositeSpec(
            {
                # agent-local observations
                "observation_self": UnboundedContinuousTensorSpec(
                    shape=(self.num_agents, 2), # (x, y) position
                    device=self.device,
                ),
                "observation_target_vector": UnboundedContinuousTensorSpec(
                    shape=(self.num_agents, 2), # vector to target (dx, dy)
                    device=self.device,
                ),
                # (Optional) global observation for critic (or part of actor obs if needed)
                # "observation_all_positions": UnboundedContinuousTensorSpec(
                #     shape=(self.num_agents, 2),
                #     device=self.device,
                # ),
                "agents_done": DiscreteTensorSpec( # Track individual agent done status (not strictly needed if all done together)
                    n=2,
                    shape=(self.num_agents, 1),
                    dtype=torch.bool,
                    device=self.device,
                )
            },
            shape=(self.num_agents,) # This indicates group "agent"
        )
        # Add "agent" group name to observation_spec keys if needed by collector
        self.observation_spec = self.observation_spec.to(self.device)


        # Shared policy, so action spec is for a single agent, collector will handle batching
        self.action_spec = BoundedTensorSpec(
            low=-1.0,
            high=1.0,
            shape=(self.num_agents, 2), # (dx, dy) for each agent
            device=self.device,
            dtype=torch.float32
        )
        self.reward_spec = UnboundedContinuousTensorSpec(
            shape=(self.num_agents, 1),
            device=self.device
        )
        self.done_spec = DiscreteTensorSpec(
            n=2, # True or False
            shape=(self.num_agents, 1), # Overall episode done
            dtype=torch.bool,
            device=self.device
        )


    def _reset(self, tensordict: TensorDictBase = None) -> TensorDictBase:
        self.current_step = 0

        # Initialize agent positions (randomly for now)
        agent_positions = (torch.rand(self.num_agents, 2, device=self.device) - 0.5) * self.arena_size

        # Define target positions (e.g., on a circle)
        target_positions = torch.zeros(self.num_agents, 2, device=self.device)
        for i in range(self.num_agents):
            angle = 2 * math.pi * i / self.num_agents
            target_positions[i, 0] = self.target_radius * math.cos(angle)
            target_positions[i, 1] = self.target_radius * math.sin(angle)

        self.agent_positions = agent_positions
        self.target_positions = target_positions

        obs_self = self.agent_positions.clone()
        obs_target_vector = self.target_positions - self.agent_positions
        # obs_all_pos = self.agent_positions.clone() # For critic if used

        done = torch.zeros((self.num_agents,1), dtype=torch.bool, device=self.device)

        # Construct the output tensordict
        # Note: The structure of the tensordict (especially nesting for groups)
        # might need adjustment based on how the collector and policy expect it.
        # For a simple shared policy setup, we provide observations for all agents.
        td_out = TensorDict(
            {
                "observation_self": obs_self,
                "observation_target_vector": obs_target_vector,
                # "observation_all_positions": obs_all_pos, # if used
                "agents_done": done,
                "done": done, # Episode done for all agents (can be different)
            },
            batch_size=[self.num_agents], # This is key for group based MARL
            device=self.device
        )
        return td_out

    def _step(self, tensordict: TensorDictBase) -> TensorDictBase:
        self.current_step += 1
        actions = tensordict["action"] # Expected shape: (num_agents, 2)

        # Update agent positions (simple kinematics)
        # Action values are dx, dy. Scale them if needed.
        self.agent_positions += actions * 0.1 # Small step size

        # Keep agents within bounds (optional, can also be part of reward)
        self.agent_positions = torch.clamp(self.agent_positions, -self.arena_size / 2, self.arena_size / 2)

        # Calculate rewards
        # Simple reward: negative sum of distances to target positions for each agent
        distances_to_target = torch.norm(self.agent_positions - self.target_positions, dim=1, keepdim=True)
        reward = -distances_to_target

        # Termination condition
        done = self.current_step >= self.max_steps
        # For MARL, done can be per-agent or global. Here, global.
        done_tensor = torch.full((self.num_agents, 1), done, dtype=torch.bool, device=self.device)

        # Observations for next step
        obs_self = self.agent_positions.clone()
        obs_target_vector = self.target_positions - self.agent_positions
        # obs_all_pos = self.agent_positions.clone() # For critic if used

        td_out = TensorDict(
            {
                "observation_self": obs_self,
                "observation_target_vector": obs_target_vector,
                # "observation_all_positions": obs_all_pos,
                "reward": reward,
                "agents_done": done_tensor, # Per agent done status
                "done": done_tensor,      # Episode done signal
            },
            batch_size=[self.num_agents],
            device=self.device
        )
        return td_out

    def _set_seed(self, seed: int):
        # For reproducibility
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        # Note: Python's `random` module might also need seeding if used