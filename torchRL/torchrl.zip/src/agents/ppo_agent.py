import torch
import torch.nn as nn
from tensordict.nn import TensorDictModule, TensorDictSequential
from torchrl.modules import MLP, ProbabilisticActor, TanhNormal, ValueOperator

def create_ppo_actor_critic(cfg, proof_environment):
    """
    Creates actor and critic modules for PPO.
    This setup assumes a shared policy for all agents.
    """
    device = torch.device(cfg.base.device)
    env_cfg = cfg.env
    algo_cfg = cfg.algo

    # Actor Network
    # Observation for actor: concatenation of its own features
    # For this simple env: obs_self (pos) + obs_target_vector
    # Shape: (num_agents, obs_dim)
    # We build a policy that processes one agent's observation at a time
    # The collector will handle batching observations from multiple agents.

    # Determine actor input dimension based on specified obs_keys
    actor_obs_dim = 0
    actor_in_keys = [] # For TensorDictModule
    if "observation_self" in env_cfg.obs_keys:
        actor_obs_dim += proof_environment.observation_spec["observation_self"].shape[-1]
        actor_in_keys.append("observation_self")
    if "observation_target_vector" in env_cfg.obs_keys:
        actor_obs_dim += proof_environment.observation_spec["observation_target_vector"].shape[-1]
        actor_in_keys.append("observation_target_vector")

    # The MLP will take a flat vector. We'll need a pre-processing step if obs are separate.
    # Or, for simplicity, assume we concatenate them before passing to MLP.
    # For now, let's make MLP input dim the sum of individual obs features.

    actor_mlp = MLP(
        in_features=actor_obs_dim,
        out_features=2 * proof_environment.action_spec.shape[-1], # For mean and std of TanhNormal
        hidden_sizes=list(algo_cfg.hidden_dims),
        activation_class=nn.Tanh,
        device=device,
    )

    # Use TanhNormal for bounded continuous actions
    actor_module = ProbabilisticActor(
        module=actor_mlp,
        spec=proof_environment.action_spec, # Pass the single agent action spec
        in_keys=actor_in_keys, # These keys from the TensorDict will be fed to the MLP
        distribution_class=TanhNormal,
        distribution_kwargs={"min": proof_environment.action_spec.space.low,
                             "max": proof_environment.action_spec.space.high},
        return_log_prob=True,
        # Fpr a shared policy, actor_in_keys refers to the observation components for a single agent.
        # The policy will be applied to each agent's observation.
    )

    # Critic Network
    # For CTDE, critic can have access to more information.
    # Here, for simplicity, it uses the same observation as the actor.
    # You could extend critic_in_keys to include e.g., "observation_all_positions".
    critic_obs_dim = actor_obs_dim # Same as actor for this skeleton
    critic_in_keys = actor_in_keys # Same as actor for this skeleton

    critic_mlp = MLP(
        in_features=critic_obs_dim,
        out_features=1, # Value function is a scalar
        num_cells=list(algo_cfg.hidden_dims), # <--- CHANGE 'hidden_sizes' to 'num_cells'
        activation_class=nn.Tanh, # Or torchrl.modules.Tanh
        device=device,
    )
    # Wrap critic MLP in ValueOperator
    # ValueOperator expects the observation keys as input and outputs "state_value"
    value_module = ValueOperator(
        module=critic_mlp,
        in_keys=critic_in_keys, # What the critic MLP sees
        # out_keys=["state_value"] # Default out_key
    )

    return actor_module, value_module